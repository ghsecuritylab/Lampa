# ESPeasySerial

A wrapper to offer a standard interface to serial port on Arduino based ESP8266 as well as ESP32.
This wrapper abstracts the use of HW and SW serial.
