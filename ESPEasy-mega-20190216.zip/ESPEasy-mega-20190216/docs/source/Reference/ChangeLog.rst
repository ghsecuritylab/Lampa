Change Log
***********


2.0
---

.. versionadded:: 2.0
  ...

  |added|
  [docs] Abandoned WikiMedia format and converted to ReadTheDocs.

  |removed|
  [udp] ESP Easy interconnect is now a controller.

  |fixed|
  [bug] Save didn't work for...
