System Variables
****************
