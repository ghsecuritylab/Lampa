Changelog
---------
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

\[Unreleased\]
==============

### Added
-   None.

### Changed
-   None.

### Removed
-   None.

### Fixed
-   None.

### Security
-   None.

\[1.0.0\] 2018-09-19
====================

### Added
-   Initial release.
-   Tested support for MCP3002 and MCP3008. MCP3004 should also work out of the box, but is untested.

### Changed
-   None

### Removed
-   None

### Fixed
-   None

### Security
-   None
